import React from 'react';
import RotatingText from '../components/RotatingText';

const Home = () => {
    return (
        <div>
            <RotatingText/>
        </div>
    );
};

export default Home;